﻿using UnityEngine;
using System.Collections;

public class AutoMap : MonoBehaviour {

	public int tileX = 20;
	public int tileY = 20;

	void Start () {
	}
}
