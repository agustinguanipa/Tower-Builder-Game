San Francisco House.

This package contains 12 variations of San Francisco house.
Model of the house have 4065 vertices and 2354 triangles.

This package is optimized to run in Unity and ready for use in your projects.